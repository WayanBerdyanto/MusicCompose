package com.dicoding.mymusiccompose.model

data class MusicCategory(
    val id: String,
    val nameCategory: String,
    val imageCategory: String
)